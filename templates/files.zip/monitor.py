"""
Bot de alertas de futbol - V12
- SOLO alerta en ligas de nivel "Muy alta"
- Alerta 1: 4-0 o 0-4 antes del minuto 34
- Alerta 2: 3-1 o 1-3 antes del minuto 28 (incluye dato Under 8.5)
- Alerta 3: MEDIO TIEMPO 4-0/0-4 o 3-1/1-3 al terminar el primer tiempo
- Envia 3 mensajes a Telegram con frases motivadoras
"""

import os
import time
import random
import requests
from dotenv import load_dotenv
from ligas_under import under_liga
from ligas_nivel import nivel_liga

load_dotenv()

API_FOOTBALL_KEY = os.getenv("API_FOOTBALL_KEY")
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

URL_API = "https://v3.football.api-sports.io/fixtures"
URL_TELEGRAM = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"

alertas_enviadas = set()

FRASES_MOTIVADORAS = [
    ("Esta es la nuestra, equipo", "Vamos con todo"),
    ("El exito favorece a los preparados", "A brillar"),
    ("Las matematicas estan de nuestro lado", "Suerte chicos"),
    ("Las oportunidades no se piden, se toman", "Sin miedo"),
    ("El momento es ahora", "A la caja"),
    ("No hay limites cuando hay confianza", "Por la victoria"),
    ("Disciplina + estrategia = resultados", "A por todo"),
    ("Los grandes momentos se construyen", "Vamos por mas"),
    ("La constancia siempre paga", "Hoy es el dia"),
    ("Cada decision cuenta", "Despeguemos"),
    ("Los ganadores actuan rapido", "A romperla"),
    ("Esto es lo que esperabamos", "Que sea la nuestra"),
]

EMOJIS_MOTIVADOR = ["💪", "🏆", "🔥", "💎", "⚡", "🚀", "🎯", "🌟", "📈"]
EMOJIS_CIERRE = ["🚀", "⭐", "🍀", "🎯", "💰", "🏅", "💪", "🔥", "🎰", "⚡"]


def enviar_mensaje_telegram(texto):
    try:
        respuesta = requests.post(URL_TELEGRAM, data={
            "chat_id": TELEGRAM_CHAT_ID,
            "text": texto,
            "parse_mode": "HTML"
        }, timeout=10)
        return respuesta.status_code == 200
    except Exception as e:
        print(f"Error enviando mensaje: {e}")
        return False


def enviar_alerta_completa(equipo_local, gol_local, gol_visitante, equipo_visitante, minuto, liga, pais, tipo_alerta):
    """Envia 3 mensajes separados: info, motivacion, cierre"""

    if tipo_alerta == "goleada_4_0":
        titulo = "🚨 GOLEADA EXTREMA"
    elif tipo_alerta == "goleada_3_1":
        titulo = "🚨 ALERTA UNDER 8.5"
    elif tipo_alerta == "medio_tiempo":
        titulo = "🚨 ALERTA MEDIO TIEMPO"
    else:
        titulo = "🚨 ALERTA"

    if tipo_alerta == "medio_tiempo":
        linea_minuto = "⏱ Medio tiempo"
    else:
        linea_minuto = f"⏱ Minuto {minuto}"

    linea_under = ""
    if tipo_alerta == "goleada_3_1":
        datos_under = under_liga(pais, liga)
        if datos_under:
            palabra = "juego" if datos_under["juegos"] == 1 else "juegos"
            linea_under = f"\n📊 Under 8.5: {datos_under['pct']} ganados ({datos_under['juegos']} {palabra})"

    msg1 = (
        f"{titulo}\n\n"
        f"⚽ <b>{equipo_local} {gol_local}-{gol_visitante} {equipo_visitante}</b>\n"
        f"🏆 {liga} - {pais}\n"
        f"{linea_minuto}"
        f"{linea_under}"
    )

    frase_motivador, frase_cierre = random.choice(FRASES_MOTIVADORAS)
    emoji_m = random.choice(EMOJIS_MOTIVADOR)
    emoji_c = random.choice(EMOJIS_CIERRE)

    msg2 = f"{emoji_m} <b>{frase_motivador}</b>"
    msg3 = f"{emoji_c} <b>{frase_cierre}</b>"

    enviar_mensaje_telegram(msg1)
    time.sleep(0.8)
    enviar_mensaje_telegram(msg2)
    time.sleep(0.8)
    enviar_mensaje_telegram(msg3)

    print(f"  ✓ Alertas enviadas ({tipo_alerta}): {equipo_local} {gol_local}-{gol_visitante} {equipo_visitante}")


def consultar_partidos_en_vivo():
    headers = {"x-apisports-key": API_FOOTBALL_KEY}
    try:
        respuesta = requests.get(URL_API, headers=headers, params={"live": "all"}, timeout=15)
        if respuesta.status_code == 200:
            return respuesta.json().get("response", [])
        print(f"Error API: {respuesta.status_code}")
        return []
    except Exception as e:
        print(f"Error conexion: {e}")
        return []


def revisar_partido(partido):
    try:
        fixture_id = partido["fixture"]["id"]
        minuto = partido["fixture"]["status"]["elapsed"]
        gol_local = partido["goals"]["home"] or 0
        gol_visitante = partido["goals"]["away"] or 0

        # Solo alertamos en ligas de nivel "Muy alta"
        niv = nivel_liga(partido["league"]["country"], partido["league"]["name"])
        if not niv or niv["clase"] != "muy_alta":
            return

        estado_corto = partido["fixture"]["status"]["short"]
        diferencia = abs(gol_local - gol_visitante)
        max_goles = max(gol_local, gol_visitante)
        min_goles = min(gol_local, gol_visitante)

        tipo_alerta = None

        # Alerta 3: MEDIO TIEMPO (4-0/0-4 o 3-1/1-3 al terminar el primer tiempo)
        if estado_corto == "HT" and ((max_goles >= 4 and diferencia >= 4) or (max_goles == 3 and min_goles == 1)):
            tipo_alerta = "medio_tiempo"

        # Alertas en juego (requieren el minuto)
        elif minuto is not None:
            # Alerta 1: 4-0 o 0-4 antes del minuto 34
            if max_goles >= 4 and diferencia >= 4 and minuto <= 34:
                tipo_alerta = "goleada_4_0"
            # Alerta 2: 3-1 o 1-3 antes del minuto 28
            elif max_goles == 3 and min_goles == 1 and minuto <= 28:
                tipo_alerta = "goleada_3_1"

        if tipo_alerta is None:
            return

        marcador = f"{gol_local}-{gol_visitante}"
        id_alerta = f"{fixture_id}_{marcador}_{tipo_alerta}"

        if id_alerta in alertas_enviadas:
            return

        alertas_enviadas.add(id_alerta)

        enviar_alerta_completa(
            equipo_local=partido["teams"]["home"]["name"],
            gol_local=gol_local,
            gol_visitante=gol_visitante,
            equipo_visitante=partido["teams"]["away"]["name"],
            minuto=minuto,
            liga=partido["league"]["name"],
            pais=partido["league"]["country"],
            tipo_alerta=tipo_alerta
        )
    except Exception as e:
        print(f"Error revisando partido: {e}")


def main():
    print("=" * 50)
    print("BOT DE ALERTAS DE GOLEADAS - V12")
    print("=" * 50)
    print("Condiciones de alerta:")
    print("  1. 4-0 o 0-4 antes del minuto 34")
    print("  2. 3-1 o 1-3 antes del minuto 28 (con dato Under 8.5)")
    print("  3. Medio tiempo: 4-0/0-4 o 3-1/1-3 al terminar el 1er tiempo")
    print("  * SOLO en ligas de nivel Muy alta")
    print()
    print("Cada alerta envia 3 mensajes a Telegram")
    print("Intervalo de consulta: cada 30 segundos")
    print("=" * 50)
    print()

    while True:
        try:
            partidos = consultar_partidos_en_vivo()
            print(f"[{time.strftime('%H:%M:%S')}] Partidos en vivo: {len(partidos)} | Alertas hoy: {len(alertas_enviadas)}")

            for partido in partidos:
                revisar_partido(partido)

            time.sleep(30)
        except KeyboardInterrupt:
            print("\nBot detenido.")
            break
        except Exception as e:
            print(f"Error: {e}")
            time.sleep(30)


if __name__ == "__main__":
    main()